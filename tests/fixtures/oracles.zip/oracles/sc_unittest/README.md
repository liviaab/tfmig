# Simple Case Oracle
## Unittest project since the beginning

This repository simulates one that uses the python test framework "unittest" since the beginning.