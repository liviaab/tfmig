class Person:
    """
    This is a Person class. Tests should be written using unittest.
    """
    def __init__(self, name, age):
        self.name = name
        self.age = age