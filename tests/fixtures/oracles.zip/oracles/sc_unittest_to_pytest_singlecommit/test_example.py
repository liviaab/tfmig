import pytest

def inc(x):
    return x + 1

def test_answer():
    assert inc(3) == 4

def test_answer_big_number():
    assert inc(12345678987) == 12345678988
